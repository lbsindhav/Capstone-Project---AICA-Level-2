SMART PURCHASE & CREDIT CARD TRACKING SYSTEM — WINDOWS PORTABLE EDITION — VERSION 1.4

START:
1. Extract this ZIP to a normal folder (for example, Desktop\SmartPurchase).
2. Double-click START_APP.cmd.
3. On FIRST RUN, the launcher AUTOMATICALLY DOWNLOADS the official Microsoft Windows portable
   Python runtime from python.org (requires internet; no installation or pip required).
   Later launches do NOT require the runtime download.
4. Browser opens http://127.0.0.1:8765 . Keep the command window open.

INITIAL ADMIN LOGIN:
Username: admin
Password: Admin@123
The app REQUIRES password change on first sign-in. Choose a strong new password.

INCLUDED FEATURES:
- Firm, vendor, item and combined credit cardholder masters
- Two or more firms; purchase invoices with multiple items
- Detailed searchable item names and optional IMEI 1 / IMEI 2 / serial per unit
- Invoice attachment PDF/JPG/PNG/WebP (up to 7MB)
- Multiple credit cards for one invoice; partial allocation and over-allocation checks
- Card utilisation by firm, vendor and item; CSV/XLSX/PDF reports
- Sample Excel templates and CSV / simple XLSX bulk imports with preview, validation,
  duplicate checking and error reporting
- Admin-created users and firm-level permissions; change-password and audit records
- Responsive browser interface and PWA manifest

IMPORTANT LIMITATIONS:
- This edition is a LOCAL single-PC application. The data is stored on THIS computer in
  data\smart_purchase.sqlite3. It is NOT a cloud database and does not automatically sync
  between devices. Do not expose this HTTP app to the internet or public Wi-Fi.
- Other authorised people can use separate user logins sequentially on the same machine.
- On a phone, the interface is designed to adapt to small screens, but this local-only
  package does not provide remote access, HTTPS hosting, or cross-device synchronisation.
  Those need a cloud deployment with TLS and server-side hardening.
- The application tracks PURCHASES charged to cards, not actual bank card outstanding,
  repayments or card bill settlement.
- PDF export uses basic text formatting; very wide reports may truncate columns.
- No Python installer, pip, third-party Python packages or internet needed after portable
  runtime download. Windows 10 or Windows 11 (64 bit) is required.

DATABASE BACKUP:
Close the application before backing up, then copy the entire 'data' folder to secure
storage (it contains the database and uploaded invoices). Keep your admin password safe.

SOURCE CODE:
app\server.py and app\static\ contain the editable Python source and interface.

TROUBLESHOOTING:
- If the first download is blocked, ask your IT admin to download the exact official
  python-3.12.9-embed-amd64.zip from python.org and extract it to the runtime folder.
- If localhost:8765 is already in use, close the previous running window.
- For XLSX import, use a current Chromium or Edge browser; CSV is the universal fallback.
- This version should be tested with real invoice and tax cases before production use.

VERSION 1.3 CHANGES:
- Purchase Register and exported Purchase Register report now show Card Usage Details:
  cardholder, issuer, masked last four card digits and allocated amount per invoice.
- Create users with letters, numbers, symbols, spaces or non-English characters;
  no previous restricted username pattern. A technical max of 255 characters applies.
- Password creation/reset requires minimum 8 characters, without composition rules.
- Add/Edit Item supports optional live suggestions from public Wikidata results as you type.
  Only search words typed in Item Name are shared with Wikidata; this requires internet.
  Product variants (storage, colour, etc.) may need to be entered manually.

UPGRADING WITHOUT LOSING DATA:
Close the old application. Extract this new ZIP to a separate folder.
Copy the ENTIRE old data folder into the new SmartPurchase_Portable folder, replacing
its empty data folder, then start with START_APP.cmd. Do not copy the runtime folder
unless you want to avoid the Python first-run download; copying your prior runtime
folder is safe if it is working.

VERSION 1.3 ADDITIONAL CHANGES:
- Selecting an item suggestion auto-fills available brand, model and specifications.
- Storage and colour are extracted only if explicitly present in the returned product title.
- Locally saved items also appear in the search with saved specifications;
  Brand, Model and Specifications fields offer browser autocomplete from previous entries.
- Online Wikidata is not a verified detailed retailer product catalogue. Many variants
  will have incomplete information; manually confirm storage, colour and model.

VERSION 1.4 - PURCHASE REGISTER & TRANSACTION JOURNAL:
- Purchase Register now lists ONE ROW PER CARD ALLOCATION, with distinct columns:
  Cardholder Name, Card Issuer, Card Number (CC-1234), Amount Utilised, Transaction Reference.
- Invoice-level totals, tax and aggregate allocated/unallocated appear ONLY on the first
  allocation row for an invoice to prevent double-counting when summing Excel reports.
- Includes a new Transaction Journal menu and an Advanced Journal Search button in Reports.
- Multiple combined filters: date range, firm, vendor, item, card, cardholder, issuer,
  invoice number, IMEI, serial number, status, amount range, row type and full-text search.
- Transaction Journal shows ITEM records and CARD allocation records separately, with
  all available invoice, master, tax, description, IMEI/serial and payment reference fields.
  Note: Invoice Total is repeated as reference information in the journal; never sum it.
- Journal reports export to Excel (.xlsx), CSV, and PDF. Wide PDFs may truncate columns;
  Excel is recommended for full transaction detail.

UPGRADE SAFELY:
1. Close previous application and its command window.
2. Extract this ZIP into a NEW folder.
3. Copy the ENTIRE data folder from the previous SmartPurchase_Portable into this one
   (replacing the empty data folder). This preserves users, changed passwords, invoices,
   attachments and database records.
4. Start with START_APP.cmd, then press Ctrl+F5 in the browser.
5. To avoid the first-run runtime download, you may copy the previously working runtime
   folder as well. Do NOT overwrite your old data with an empty folder.

VERSION 1.5 - ONE-ROW PURCHASE REGISTER:
- Purchase Register now has exactly one row per invoice, even with many credit cards.
- Columns dynamically repeat: cardholder_name_1, card_issuer_1, card_number_1,
  amount_utilised_1, then corresponding _2, _3, etc. No fixed card count.
- The most cards used by any invoice in the chosen report determines how many
  groups are exported. Unused card fields are blank.
- The on-screen Purchase Register follows the same column arrangement.
- Amounts and invoice totals appear once per invoice for correct Excel sums.
- Transaction Journal and all other modules remain unchanged.
- PDF export has a limited page width, and may not show all repeating columns.
  Use Excel/CSV for the full-width report.
- To retain existing data copy the OLD data folder into this version before launch.
