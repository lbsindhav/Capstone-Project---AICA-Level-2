$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$python = Join-Path $root 'runtime\python.exe'
if (-not (Test-Path $python)) {
  Write-Host 'First run: obtaining official portable Python runtime (no Python installation needed)...' -ForegroundColor Cyan
  $url = 'https://www.python.org/ftp/python/3.12.9/python-3.12.9-embed-amd64.zip'
  $zip = Join-Path $root 'python_portable_download.zip'
  $runtime = Join-Path $root 'runtime'
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    Expand-Archive -Path $zip -DestinationPath $runtime -Force
    Remove-Item $zip -Force
    if (-not (Test-Path $python)) { throw 'Portable runtime was not extracted correctly.' }
  } catch {
    Write-Host ('Download failed: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'An internet connection is required on first run to download the official Windows Python runtime.'
    exit 1
  }
}
Write-Host 'Starting Smart Purchase & Credit Card Tracking System...' -ForegroundColor Green
Write-Host 'Open http://127.0.0.1:8765 if the browser does not open automatically.'
Write-Host 'Keep this window open while using the application. Press Ctrl+C to stop.'
& $python (Join-Path $root 'app\server.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
