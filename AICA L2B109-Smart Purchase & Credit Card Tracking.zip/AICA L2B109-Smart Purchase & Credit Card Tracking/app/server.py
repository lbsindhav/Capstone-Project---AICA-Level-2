"""Smart Purchase & Credit Card Tracker. Python standard library only."""
import urllib.request, base64, csv, datetime as dt, hashlib, hmac, io, json, mimetypes, os, re, secrets, sqlite3, sys, threading, time, urllib.parse, webbrowser, zipfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parent
DATA=ROOT.parent/'data'; DATA.mkdir(exist_ok=True)
UPLOADS=DATA/'uploads'; UPLOADS.mkdir(exist_ok=True)
DB=DATA/'smart_purchase.sqlite3'
STATIC=ROOT/'static'
SESSIONS={}; LOCK=threading.Lock(); LOGIN_ATTEMPTS={}
SCHEMAS={
 'firms': [('name','required'),('gstin',''),('state',''),('address','')],
 'vendors':[('name','required'),('gstin',''),('city',''),('state',''),('phone',''),('channel','')],
 'items':[('name','required'),('brand',''),('model',''),('specifications',''),('hsn',''),('gst_rate','float'),('price','float')],
 'cards':[('holder','required'),('issuer','required'),('last4','last4')]
}

def db():
 c=sqlite3.connect(DB,timeout=20);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA busy_timeout=20000');return c

def passwd(p,s=None):
 s=s or secrets.token_hex(16)
 return s+'$'+hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(s),250000).hex()
def checkpw(p,stored):
 try:
  s,v=stored.split('$',1);return hmac.compare_digest(passwd(p,s).split('$')[1],v)
 except: return False

def init():
 with db() as c:
  c.executescript('''PRAGMA journal_mode=WAL;
  CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',active INTEGER DEFAULT 1,can_add_masters INTEGER DEFAULT 1,allowed_firms TEXT DEFAULT '*',must_change INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS firms(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,gstin TEXT,state TEXT,address TEXT,deleted INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS vendors(id INTEGER PRIMARY KEY,name TEXT NOT NULL,gstin TEXT,city TEXT,state TEXT,phone TEXT,channel TEXT,deleted INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,name TEXT NOT NULL,brand TEXT,model TEXT,specifications TEXT,hsn TEXT,gst_rate REAL DEFAULT 0,price REAL DEFAULT 0,deleted INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS cards(id INTEGER PRIMARY KEY,holder TEXT NOT NULL,issuer TEXT NOT NULL,last4 TEXT NOT NULL,deleted INTEGER DEFAULT 0,UNIQUE(holder,issuer,last4));
  CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY,firm_id INTEGER NOT NULL REFERENCES firms(id),vendor_id INTEGER NOT NULL REFERENCES vendors(id),invoice_no TEXT NOT NULL,invoice_date TEXT NOT NULL,notes TEXT,attachment TEXT,subtotal REAL NOT NULL,discount REAL NOT NULL,tax REAL NOT NULL,total REAL NOT NULL,status TEXT NOT NULL DEFAULT 'recorded',created_by INTEGER REFERENCES users(id),created_at TEXT DEFAULT CURRENT_TIMESTAMP,deleted INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS purchase_lines(id INTEGER PRIMARY KEY,purchase_id INTEGER REFERENCES purchases(id) ON DELETE CASCADE,item_id INTEGER REFERENCES items(id),qty INTEGER,rate REAL,discount REAL,tax_rate REAL,tax_amount REAL,line_total REAL,description TEXT,identifiers TEXT);
  CREATE TABLE IF NOT EXISTS allocations(id INTEGER PRIMARY KEY,purchase_id INTEGER REFERENCES purchases(id) ON DELETE CASCADE,card_id INTEGER REFERENCES cards(id),amount REAL NOT NULL,transaction_ref TEXT);
  CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor INTEGER,action TEXT,object_type TEXT,object_id INTEGER,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE INDEX IF NOT EXISTS ix_purchase_date ON purchases(invoice_date);
  CREATE INDEX IF NOT EXISTS ix_allocations_card ON allocations(card_id);
  ''')
  if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
   c.execute('INSERT INTO users(username,password,role,must_change) VALUES (?,?,?,1)',('admin',passwd('Admin@123'),'admin'))

def audit(c,user,action,kind,obj,details=''):
 c.execute('INSERT INTO audit(actor,action,object_type,object_id,details) VALUES (?,?,?,?,?)',(user,action,kind,obj,str(details)[:500]))

def jsend(h,body,status=200,content_type='application/json',filename=None):
 data=body if isinstance(body,bytes) else (json.dumps(body,ensure_ascii=False).encode() if content_type=='application/json' else body.encode())
 h.send_response(status);h.send_header('Content-Type',content_type+('; charset=utf-8' if content_type.startswith('text/') or content_type=='application/json' else ''))
 h.send_header('Content-Length',str(len(data)));h.send_header('X-Content-Type-Options','nosniff');h.send_header('Cache-Control','no-store')
 h.send_header('X-Frame-Options','DENY');h.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'")
 if filename:h.send_header('Content-Disposition',f'attachment; filename="{filename}"')
 h.end_headers();h.wfile.write(data)

def fields_of(kind):return [x for x,_ in SCHEMAS[kind]]
def validate(kind,x):
 out={}
 for key,typ in SCHEMAS[kind]:
  v=x.get(key,'')
  if typ=='required' and not str(v).strip():raise ValueError(key+' is required')
  if typ=='last4' and not re.fullmatch(r'\d{4}',str(v)):raise ValueError('Card last4 must be exactly 4 digits')
  if typ=='float':
   try:v=float(v or 0)
   except:raise ValueError(key+' must be numeric')
   if v<0:raise ValueError(key+' cannot be negative')
  elif key=='gstin':
   v=str(v).strip().upper()
   if v and not re.fullmatch(r'\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]',v):raise ValueError('Invalid GSTIN format')
  else:v=str(v).strip()[:300]
  out[key]=v
 return out

def allowed(user,firm):
 return user['role']=='admin' or user['allowed_firms']=='*' or str(firm) in user['allowed_firms'].split(',')
def sql_firm_filter(user,alias='p'):
 if user['role']=='admin' or user['allowed_firms']=='*':return '',[]
 ids=[int(x) for x in user['allowed_firms'].split(',') if x.isdigit()]
 if not ids:return ' AND 1=0',[]
 return f' AND {alias}.firm_id IN ({",".join("?"*len(ids))})',ids

def report_rows(c,user,name,params):
 ff,fa=sql_firm_filter(user)
 period=''; args=[]
 for key,op in [('start','>='),('end','<=')]:
  if params.get(key):period+=f' AND p.invoice_date {op} ?';args.append(params[key])
 if params.get('firm') and str(params['firm']).isdigit():period+=' AND p.firm_id=?';args.append(int(params['firm']))
 period+=ff;args+=fa
 if name=='journal':
  return journal_rows(c,user,params)
 if name=='purchases':
  # One invoice = one row. Repeating groups expand to the largest number of
  # card allocations in this filtered report. No practical fixed card limit.
  base_sql='''SELECT p.id,p.invoice_date,p.invoice_no,f.name firm,v.name vendor,
  p.subtotal,p.discount,p.tax,p.total invoice_total,p.status,
  ROUND(COALESCE((SELECT SUM(z.amount) FROM allocations z WHERE z.purchase_id=p.id),0),2) card_allocated,
  ROUND(p.total-COALESCE((SELECT SUM(z.amount) FROM allocations z WHERE z.purchase_id=p.id),0),2) unallocated
  FROM purchases p JOIN firms f ON f.id=p.firm_id JOIN vendors v ON v.id=p.vendor_id
  WHERE p.deleted=0'''+period+''' ORDER BY p.invoice_date DESC,p.id DESC'''
  invoices=[dict(x) for x in c.execute(base_sql,args)]
  if not invoices:return []
  purchase_ids=[x['id'] for x in invoices]
  alloc_by_id={pid:[] for pid in purchase_ids}
  # Batch allocations using bounded IN queries so large reports remain safe.
  for offset in range(0,len(purchase_ids),400):
   group=purchase_ids[offset:offset+400]
   sql_alloc='''SELECT a.purchase_id,c.holder,c.issuer,c.last4,a.amount
    FROM allocations a JOIN cards c ON c.id=a.card_id
    WHERE a.purchase_id IN ('''+','.join('?' for _ in group)+''') ORDER BY a.purchase_id,a.id'''
   for a in c.execute(sql_alloc,group):alloc_by_id[a['purchase_id']].append(a)
  largest=max(map(len,alloc_by_id.values()))
  for invoice in invoices:
   for n in range(1,largest+1):
    group=alloc_by_id[invoice['id']]
    card=group[n-1] if len(group)>=n else None
    invoice['cardholder_name_'+str(n)]=card['holder'] if card else ''
    invoice['card_issuer_'+str(n)]=card['issuer'] if card else ''
    invoice['card_number_'+str(n)]='CC-'+card['last4'] if card else ''
    invoice['amount_utilised_'+str(n)]=round(card['amount'],2) if card else ''
  return invoices
 elif name=='cards':
  sql='''SELECT c.holder,c.issuer,c.last4, f.name firm,round(SUM(a.amount),2) purchase_utilisation,COUNT(DISTINCT p.id) invoices FROM allocations a JOIN cards c ON c.id=a.card_id JOIN purchases p ON p.id=a.purchase_id JOIN firms f ON f.id=p.firm_id WHERE p.deleted=0'''+period+''' GROUP BY c.id,p.firm_id ORDER BY c.holder,c.issuer,c.last4,f.name'''
 elif name=='vendors':
  sql='''SELECT v.name vendor, f.name firm,COUNT(*) invoices,round(SUM(p.total),2) total FROM purchases p JOIN vendors v ON v.id=p.vendor_id JOIN firms f ON f.id=p.firm_id WHERE p.deleted=0'''+period+''' GROUP BY p.vendor_id,p.firm_id ORDER BY total DESC'''
 elif name=='items':
  sql='''SELECT i.name item,f.name firm,SUM(l.qty) quantity,round(SUM(l.line_total),2) amount FROM purchase_lines l JOIN items i ON i.id=l.item_id JOIN purchases p ON p.id=l.purchase_id JOIN firms f ON f.id=p.firm_id WHERE p.deleted=0'''+period+''' GROUP BY i.id,p.firm_id ORDER BY amount DESC'''
 elif name=='serials':
  sql='''SELECT p.invoice_date,p.invoice_no,f.name firm,i.name item,l.identifiers FROM purchase_lines l JOIN items i ON i.id=l.item_id JOIN purchases p ON p.id=l.purchase_id JOIN firms f ON f.id=p.firm_id WHERE p.deleted=0 AND l.identifiers!='[]' '''+period+''' ORDER BY p.invoice_date DESC'''
 elif name=='audit':
  if user['role']!='admin':raise PermissionError('Admin only')
  return [dict(x) for x in c.execute('SELECT a.created_at,u.username actor,a.action,a.object_type,a.object_id,a.details FROM audit a LEFT JOIN users u ON u.id=a.actor ORDER BY a.id DESC LIMIT 1000')]
 else:raise ValueError('Unknown report')
 return [dict(x) for x in c.execute(sql,args)]

def journal_rows(c,user,params):
 # Searchable full-field journal without item-card multiplication.
 ff,fa=sql_firm_filter(user)
 where=['p.deleted=0'];args=[]
 for key,op in [('start','>='),('end','<=')]:
  if params.get(key):where.append('p.invoice_date '+op+' ?');args.append(str(params[key]))
 for key,col in [('firm','p.firm_id'),('vendor','p.vendor_id')]:
  if str(params.get(key,'')).isdigit():where.append(col+'=?');args.append(int(params[key]))
 for key,col in [('status','p.status')]:
  if params.get(key):where.append(col+'=?');args.append(str(params[key]))
 if params.get('invoice'):
  where.append('LOWER(p.invoice_no) LIKE ?');args.append('%'+str(params['invoice']).lower()[:120]+'%')
 if params.get('item') and str(params['item']).isdigit():
  where.append('EXISTS (SELECT 1 FROM purchase_lines il WHERE il.purchase_id=p.id AND il.item_id=?)');args.append(int(params['item']))
 if params.get('card') and str(params['card']).isdigit():
  where.append('EXISTS (SELECT 1 FROM allocations aa WHERE aa.purchase_id=p.id AND aa.card_id=?)');args.append(int(params['card']))
 if params.get('holder'):
  where.append('EXISTS (SELECT 1 FROM allocations aa JOIN cards cc ON cc.id=aa.card_id WHERE aa.purchase_id=p.id AND LOWER(cc.holder) LIKE ?)');args.append('%'+str(params['holder']).lower()[:120]+'%')
 if params.get('issuer'):
  where.append('EXISTS (SELECT 1 FROM allocations aa JOIN cards cc ON cc.id=aa.card_id WHERE aa.purchase_id=p.id AND LOWER(cc.issuer) LIKE ?)');args.append('%'+str(params['issuer']).lower()[:120]+'%')
 for key,operator in [('min_amount','>='),('max_amount','<=')]:
  if str(params.get(key,'')).strip():
   try:amount=float(params[key])
   except:raise ValueError('Amount filter must be numeric')
   if not 0<=amount<=1e12:raise ValueError('Invalid amount filter')
   where.append('p.total '+operator+' ?');args.append(amount)
 for key in ('imei','serial'):
  if params.get(key):
   pattern='%'+str(params[key]).lower()[:120]+'%'
   # IMEI and serial values are stored as JSON inside purchase line identifiers.
   where.append("EXISTS (SELECT 1 FROM purchase_lines il WHERE il.purchase_id=p.id AND LOWER(il.identifiers) LIKE ?)")
   args.append(pattern)
 if params.get('q'):
  q='%'+str(params['q']).lower()[:150]+'%'
  where.append('''(LOWER(p.invoice_no) LIKE ? OR LOWER(COALESCE(p.notes,'')) LIKE ?
    OR LOWER(f.name) LIKE ? OR LOWER(v.name) LIKE ? OR LOWER(COALESCE(v.gstin,'')) LIKE ?
    OR EXISTS (SELECT 1 FROM purchase_lines il JOIN items ii ON ii.id=il.item_id
      WHERE il.purchase_id=p.id AND (LOWER(ii.name) LIKE ? OR LOWER(COALESCE(ii.brand,'')) LIKE ?
      OR LOWER(COALESCE(ii.model,'')) LIKE ? OR LOWER(COALESCE(ii.specifications,'')) LIKE ?
      OR LOWER(COALESCE(ii.hsn,'')) LIKE ? OR LOWER(COALESCE(il.description,'')) LIKE ?
      OR LOWER(COALESCE(il.identifiers,'')) LIKE ?))
    OR EXISTS (SELECT 1 FROM allocations aa JOIN cards cc ON cc.id=aa.card_id
      WHERE aa.purchase_id=p.id AND (LOWER(cc.holder) LIKE ? OR LOWER(cc.issuer) LIKE ?
      OR LOWER(cc.last4) LIKE ? OR LOWER(COALESCE(aa.transaction_ref,'')) LIKE ?)))''')
  args.extend([q]*16)
 where.append('1=1'+ff);args.extend(fa)
 base='''SELECT p.id FROM purchases p JOIN firms f ON f.id=p.firm_id
 JOIN vendors v ON v.id=p.vendor_id WHERE '''+' AND '.join(where)
 common='''p.id purchase_id,p.invoice_date,p.invoice_no,f.name firm,
 COALESCE(f.gstin,'') firm_gstin,COALESCE(f.state,'') firm_state,COALESCE(f.address,'') firm_address,
 v.name vendor,COALESCE(v.gstin,'') vendor_gstin,COALESCE(v.city,'') vendor_city,
 COALESCE(v.state,'') vendor_state,COALESCE(v.phone,'') vendor_phone,COALESCE(v.channel,'') vendor_channel,
 p.status,COALESCE(p.notes,'') invoice_notes,p.subtotal invoice_subtotal,
 p.discount invoice_discount,p.tax invoice_tax,p.total invoice_total,p.attachment invoice_attachment,
 COALESCE(u.username,'') created_by,p.created_at'''
 item='''SELECT '''+common+''','ITEM' record_type,i.name item_name,i.brand item_brand,
 i.model item_model,i.specifications item_specifications,i.hsn,i.gst_rate item_default_gst_rate,
 i.price item_default_price,l.qty quantity,l.rate rate,
 l.discount item_discount,l.tax_rate gst_rate,l.tax_amount gst_amount,l.line_total item_total,
 COALESCE(l.description,'') item_description,COALESCE(l.identifiers,'') imei_serial_details,
 '' cardholder_name,'' card_issuer,'' card_number,NULL amount_utilised,'' transaction_reference
 FROM matching m JOIN purchases p ON p.id=m.id JOIN firms f ON f.id=p.firm_id
 JOIN vendors v ON v.id=p.vendor_id LEFT JOIN users u ON u.id=p.created_by
 JOIN purchase_lines l ON l.purchase_id=p.id JOIN items i ON i.id=l.item_id'''
 card='''SELECT '''+common+''','CARD' record_type,'' item_name,'' item_brand,'' item_model,
 '' item_specifications,'' hsn,NULL item_default_gst_rate,NULL item_default_price,
 NULL quantity,NULL rate,NULL item_discount,NULL gst_rate,
 NULL gst_amount,NULL item_total,'' item_description,'' imei_serial_details,
 cc.holder cardholder_name,cc.issuer card_issuer,'CC-'||cc.last4 card_number,
 a.amount amount_utilised,COALESCE(a.transaction_ref,'') transaction_reference
 FROM matching m JOIN purchases p ON p.id=m.id JOIN firms f ON f.id=p.firm_id
 JOIN vendors v ON v.id=p.vendor_id LEFT JOIN users u ON u.id=p.created_by
 JOIN allocations a ON a.purchase_id=p.id JOIN cards cc ON cc.id=a.card_id'''
 query='WITH matching AS ('+base+') SELECT * FROM ('+item+' UNION ALL '+card+') ORDER BY invoice_date DESC,purchase_id DESC,record_type DESC'
 rows=[dict(r) for r in c.execute(query,args)]
 kind=str(params.get('record_type','')).upper()
 if kind in ('ITEM','CARD'):rows=[r for r in rows if r['record_type']==kind]
 return rows

def csvbytes(rows):
 o=io.StringIO(); cols=list(rows[0]) if rows else ['No records']; w=csv.DictWriter(o,fieldnames=cols);w.writeheader();w.writerows(rows);return '\ufeff'.encode()+o.getvalue().encode()
def xlsxbytes(rows):
 # Minimal standards-compliant XLSX, no external Python libraries required.
 cols=list(rows[0]) if rows else ['No records']; array=[cols]+[[r.get(k,'') for k in cols] for r in rows]
 def cell(v,j,i):
  letter='';k=j
  while k:k,mod=divmod(k-1,26);letter=chr(65+mod)+letter
  coord=f'{letter}{i}'
  if isinstance(v,(int,float)) and not isinstance(v,bool):return f'<c r="{coord}"><v>{v}</v></c>'
  txt=escape(str(v or ''))
  return f'<c r="{coord}" t="inlineStr"><is><t>{txt}</t></is></c>'
 sheet='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="16"/><sheetData>'+''.join('<row r="%d">'%i+''.join(cell(v,j,i) for j,v in enumerate(row,1))+'</row>' for i,row in enumerate(array,1))+'</sheetData></worksheet>'
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
  z.writestr('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
  z.writestr('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
  z.writestr('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Report" sheetId="1" r:id="rId1"/></sheets></workbook>')
  z.writestr('xl/worksheets/sheet1.xml',sheet)
 return buf.getvalue()

def pdfbytes(rows,title):
 # Lightweight PDF table rendered using base14 Helvetica; ASCII fallback.
 cols=list(rows[0]) if rows else ['No records']; pages=[]; ncols=min(8,len(cols)); cols=cols[:ncols]
 for off in range(0,max(1,len(rows)),34):
  lines=[title, ' | '.join(cols)[:125],'-'*100]
  for row in rows[off:off+34]:lines.append(' | '.join(str(row.get(k,''))[:18] for k in cols)[:130])
  def safe(s):return s.encode('ascii','replace').decode('ascii').replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
  stream='BT /F1 9 Tf 36 795 Td 13 TL '+' '.join(f'({safe(s)}) Tj T*' for s in lines)+' ET'
  pages.append(stream.encode('ascii'))
 objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [ '+b' '.join(f'{4+2*i} 0 R'.encode() for i in range(len(pages)))+f' ] /Count {len(pages)} >>'.encode(),b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
 for i,p in enumerate(pages):
  pid=4+2*i
  objects.extend([f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents {pid+1} 0 R >>'.encode(),b'<< /Length '+str(len(p)).encode()+b' >>\nstream\n'+p+b'\nendstream'])
 # use portrait-ish placement but header needs 795 -> set A4 portrait
 for i in range(len(pages)):objects[3+2*i]=objects[3+2*i].replace(b'842 595',b'595 842')
 out=b'%PDF-1.4\n';offsets=[0]
 for i,obj in enumerate(objects,1):offsets.append(len(out));out+=f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n'
 pos=len(out);out+=f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode()
 for n in offsets[1:]:out+=f'{n:010d} 00000 n \n'.encode()
 out+=f'trailer << /Root 1 0 R /Size {len(objects)+1} >>\nstartxref\n{pos}\n%%EOF'.encode();return out

class H(BaseHTTPRequestHandler):
 def log_message(self,fmt,*args):pass
 def cookie(self):
  m=re.search(r'(?:^|;\s*)sid=([a-f0-9]+)',self.headers.get('Cookie',''));return m.group(1) if m else ''
 def auth(self):
  token=self.cookie(); sess=SESSIONS.get(token)
  if not sess or sess[1]<time.time():return None
  with db() as c:return c.execute('SELECT * FROM users WHERE id=? AND active=1',(sess[0],)).fetchone()
 def input(self):
  n=int(self.headers.get('Content-Length','0'))
  if n>15*1024*1024:raise ValueError('Request too large (15 MB max)')
  return json.loads(self.rfile.read(n) or '{}')
 def guard(self,user,admin=False,master=False):
  if not user:raise PermissionError('Login required')
  if admin and user['role']!='admin':raise PermissionError('Admin access required')
  if master and user['role']!='admin' and not user['can_add_masters']:raise PermissionError('Master additions not permitted')
 def do_GET(self):self.route('GET')
 def do_POST(self):self.route('POST')
 def do_PUT(self):self.route('PUT')
 def do_DELETE(self):self.route('DELETE')
 def route(self,method):
  u=urllib.parse.urlsplit(self.path);path=u.path;p={k:v[0] for k,v in urllib.parse.parse_qs(u.query).items()};user=self.auth()
  try:
   if method!='GET':
    origin=self.headers.get('Origin','')
    if origin and origin!=f'http://{self.headers.get("Host", "127.0.0.1:8765")}':raise PermissionError('Invalid request origin')
   if path=='/' or path=='/index.html':return jsend(self,(STATIC/'index.html').read_bytes(),content_type='text/html')
   if path in ('/app.js','/style.css','/manifest.json','/icon.svg'):
    b=(STATIC/path[1:]).read_bytes();return jsend(self,b,content_type={'/app.js':'application/javascript','/style.css':'text/css','/manifest.json':'application/manifest+json','/icon.svg':'image/svg+xml'}[path])
   if path=='/api/login' and method=='POST':
    x=self.input();username=str(x.get('username','')).strip();pw=str(x.get('password',''))
    k=(self.client_address[0],username); now=time.time();attempts=[t for t in LOGIN_ATTEMPTS.get(k,[]) if t>now-300]
    if len(attempts)>=10:raise PermissionError('Too many attempts. Try again later.')
    with db() as c:row=c.execute('SELECT * FROM users WHERE username=? AND active=1',(username,)).fetchone()
    if not row or not checkpw(pw,row['password']):LOGIN_ATTEMPTS[k]=attempts+[now];raise PermissionError('Invalid username or password')
    sid=secrets.token_hex(32);SESSIONS[sid]=(row['id'],now+12*3600)
    data={'id':row['id'],'username':row['username'],'role':row['role'],'must_change':bool(row['must_change']),'can_add_masters':bool(row['can_add_masters'])}
    b=json.dumps(data).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.send_header('Set-Cookie',f'sid={sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(b);return
   if path=='/api/logout' and method=='POST':
    SESSIONS.pop(self.cookie(),None);return jsend(self,{'ok':True})
   self.guard(user)
   if path=='/api/me':return jsend(self,{'id':user['id'],'username':user['username'],'role':user['role'],'must_change':bool(user['must_change']),'can_add_masters':bool(user['can_add_masters'])})
   if path=='/api/password' and method=='POST':
    x=self.input()
    if not checkpw(str(x.get('old','')),user['password']):raise ValueError('Current password incorrect')
    new=str(x.get('new',''))
    if not 8<=len(new)<=1024:raise ValueError('New password must be at least 8 characters')
    with db() as c:c.execute('UPDATE users SET password=?,must_change=0 WHERE id=?',(passwd(new),user['id']));audit(c,user['id'],'password_changed','users',user['id'])
    return jsend(self,{'ok':True})
   if user['must_change'] and path!='/api/password':raise PermissionError('Change default password first')
   if path=='/api/bootstrap':
    with db() as c:
     data={kind:[dict(z) for z in c.execute('SELECT * FROM '+kind+' WHERE deleted=0 ORDER BY id DESC')] for kind in SCHEMAS}
     ff,fa=sql_firm_filter(user)
     q='''SELECT count(*) cnt,COALESCE(SUM(total),0) total FROM purchases p WHERE p.deleted=0'''+ff
     data['summary']=dict(c.execute(q,fa).fetchone())
     data['users']=[dict(z) for z in c.execute('SELECT id,username,role,active,can_add_masters,allowed_firms FROM users ORDER BY id')] if user['role']=='admin' else []
     return jsend(self,data)
   bits=path.strip('/').split('/')
   if len(bits)>=3 and bits[:2]==['api','master'] and bits[2] in SCHEMAS:
    kind=bits[2]
    if method=='POST':
     self.guard(user,master=True);x=validate(kind,self.input());keys=list(x)
     with db() as c:
      try:
       cur=c.execute(f'INSERT INTO {kind} ({",".join(keys)}) VALUES ({",".join("?"*len(keys))})',[x[k] for k in keys]);audit(c,user['id'],'create',kind,cur.lastrowid)
      except sqlite3.IntegrityError:raise ValueError('Duplicate record')
     return jsend(self,{'id':cur.lastrowid})
    if len(bits)==4 and bits[3].isdigit() and method in ('PUT','DELETE'):
     self.guard(user,admin=True);rid=int(bits[3])
     with db() as c:
      if method=='DELETE':c.execute(f'UPDATE {kind} SET deleted=1 WHERE id=?',(rid,))
      else:
       x=validate(kind,self.input());c.execute(f'UPDATE {kind} SET '+','.join(k+'=?' for k in x)+' WHERE id=?',list(x.values())+[rid])
      audit(c,user['id'],method.lower(),kind,rid)
     return jsend(self,{'ok':True})
   if path=='/api/purchases' and method=='GET':
    with db() as c:return jsend(self,report_rows(c,user,'purchases',p))
   if path=='/api/purchases' and method=='POST':
    x=self.input();firm=int(x.get('firm_id') or 0); vendor=int(x.get('vendor_id') or 0)
    if not allowed(user,firm):raise PermissionError('No access to that firm')
    invoice=str(x.get('invoice_no','')).strip();date=str(x.get('invoice_date',''))
    if not invoice or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',date):raise ValueError('Invoice number and valid date are required')
    dt.date.fromisoformat(date)
    lines=x.get('lines') or [];allocs=x.get('allocations') or []
    if not lines:raise ValueError('Add at least one item')
    subtotal=discount=tax=total=0; sanitized=[]
    with db() as c:
     if not c.execute('SELECT 1 FROM firms WHERE id=? AND deleted=0',(firm,)).fetchone():raise ValueError('Invalid firm')
     if not c.execute('SELECT 1 FROM vendors WHERE id=? AND deleted=0',(vendor,)).fetchone():raise ValueError('Invalid vendor')
     if c.execute('SELECT 1 FROM purchases WHERE firm_id=? AND vendor_id=? AND invoice_no=? AND deleted=0',(firm,vendor,invoice)).fetchone():raise ValueError('Duplicate vendor invoice for this firm')
     for row in lines:
      item=int(row.get('item_id') or 0)
      if not c.execute('SELECT 1 FROM items WHERE id=? AND deleted=0',(item,)).fetchone():raise ValueError('Select a valid item')
      qty=int(row.get('qty') or 0);rate=round(float(row.get('rate') or 0),2);disc=round(float(row.get('discount') or 0),2);gst=float(row.get('tax_rate') or 0)
      if not 1<=qty<=10000 or rate<0 or disc<0 or gst<0 or gst>100:raise ValueError('Invalid item quantity/rate/discount/GST')
      gross=round(qty*rate,2)
      if disc>gross:raise ValueError('Discount exceeds item value')
      taxable=round(gross-disc,2); line_tax=round(taxable*gst/100,2); line_total=round(taxable+line_tax,2)
      identifiers=row.get('identifiers') or []
      if not isinstance(identifiers,list) or len(identifiers)>qty:raise ValueError('IMEI/serial count exceeds quantity')
      for unit in identifiers:
       if not isinstance(unit,dict):raise ValueError('Invalid unit identifier')
      subtotal+=gross;discount+=disc;tax+=line_tax;total+=line_total
      sanitized.append((item,qty,rate,disc,gst,line_tax,line_total,str(row.get('description',''))[:1000],json.dumps(identifiers)))
     subtotal=round(subtotal,2);discount=round(discount,2);tax=round(tax,2);total=round(total,2)
     allocated=0;clean_alloc=[]
     for a in allocs:
      cid=int(a.get('card_id') or 0);amt=round(float(a.get('amount') or 0),2)
      if not c.execute('SELECT 1 FROM cards WHERE id=? AND deleted=0',(cid,)).fetchone() or amt<=0:raise ValueError('Invalid card or amount')
      allocated=round(allocated+amt,2);clean_alloc.append((cid,amt,str(a.get('transaction_ref',''))[:100]))
     if allocated>total+0.005:raise ValueError('Card allocations exceed invoice total')
     attachment=x.get('attachment','')
     if attachment and (not re.fullmatch('[a-f0-9]{32}\\.(pdf|jpg|jpeg|png|webp)',attachment) or not (UPLOADS/attachment).exists()):raise ValueError('Invalid attachment')
     cur=c.execute('INSERT INTO purchases(firm_id,vendor_id,invoice_no,invoice_date,notes,attachment,subtotal,discount,tax,total,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(firm,vendor,invoice,date,str(x.get('notes',''))[:1000],attachment,subtotal,discount,tax,total,'recorded' if abs(allocated-total)<0.005 else 'partially_allocated',user['id']))
     pid=cur.lastrowid
     c.executemany('INSERT INTO purchase_lines(purchase_id,item_id,qty,rate,discount,tax_rate,tax_amount,line_total,description,identifiers) VALUES (?,?,?,?,?,?,?,?,?,?)',[(pid,*z) for z in sanitized]);c.executemany('INSERT INTO allocations(purchase_id,card_id,amount,transaction_ref) VALUES (?,?,?,?)',[(pid,*z) for z in clean_alloc]);audit(c,user['id'],'create','purchase',pid,invoice)
    return jsend(self,{'id':pid,'total':total,'allocated':allocated})
   if len(bits)==3 and bits[:2]==['api','purchases'] and bits[2].isdigit():
    pid=int(bits[2]);
    with db() as c:
     invoice=c.execute('SELECT * FROM purchases WHERE id=? AND deleted=0',(pid,)).fetchone()
     if not invoice:raise ValueError('Invoice not found')
     if not allowed(user,invoice['firm_id']):raise PermissionError('No access to invoice')
     if method=='GET':
      d=dict(invoice);d['lines']=[dict(z) for z in c.execute('SELECT * FROM purchase_lines WHERE purchase_id=?',(pid,))];d['allocations']=[dict(z) for z in c.execute('SELECT * FROM allocations WHERE purchase_id=?',(pid,))];return jsend(self,d)
     if method=='PUT':
      self.guard(user,admin=True)
      x=self.input();firm=int(x.get('firm_id') or 0);vendor=int(x.get('vendor_id') or 0)
      if not allowed(user,firm):raise PermissionError('No access to selected firm')
      invoice_no=str(x.get('invoice_no','')).strip();invoice_date=str(x.get('invoice_date',''))
      if not invoice_no or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',invoice_date):raise ValueError('Invoice number/date required')
      dt.date.fromisoformat(invoice_date)
      if not c.execute('SELECT 1 FROM firms WHERE id=? AND deleted=0',(firm,)).fetchone():raise ValueError('Unknown firm')
      if not c.execute('SELECT 1 FROM vendors WHERE id=? AND deleted=0',(vendor,)).fetchone():raise ValueError('Unknown vendor')
      if c.execute('SELECT 1 FROM purchases WHERE firm_id=? AND vendor_id=? AND invoice_no=? AND deleted=0 AND id!=?',(firm,vendor,invoice_no,pid)).fetchone():raise ValueError('Duplicate vendor invoice')
      rows=x.get('lines') or []
      if not rows:raise ValueError('At least one item required')
      prepared=[];subtotal=discount=tax=total=0
      for row in rows:
       item=int(row.get('item_id') or 0)
       if not c.execute('SELECT 1 FROM items WHERE id=? AND deleted=0',(item,)).fetchone():raise ValueError('Invalid item')
       qty=int(row.get('qty') or 0);rate=round(float(row.get('rate') or 0),2);disc=round(float(row.get('discount') or 0),2);gst=float(row.get('tax_rate') or 0)
       if not 1<=qty<=10000 or rate<0 or disc<0 or gst<0 or gst>100 or disc>round(qty*rate,2):raise ValueError('Invalid item values')
       identifiers=row.get('identifiers') or []
       if not isinstance(identifiers,list) or len(identifiers)>qty:raise ValueError('Too many unit serials')
       taxable=round(qty*rate-disc,2);lt=round(taxable*gst/100,2);linetotal=round(taxable+lt,2)
       subtotal+=round(qty*rate,2);discount+=disc;tax+=lt;total+=linetotal
       prepared.append((pid,item,qty,rate,disc,gst,lt,linetotal,str(row.get('description',''))[:1000],json.dumps(identifiers)))
      subtotal=round(subtotal,2);discount=round(discount,2);tax=round(tax,2);total=round(total,2)
      prepared_alloc=[];allocated=0
      for a in x.get('allocations') or []:
       card=int(a.get('card_id') or 0);amount=round(float(a.get('amount') or 0),2)
       if amount<=0 or not c.execute('SELECT 1 FROM cards WHERE id=? AND deleted=0',(card,)).fetchone():raise ValueError('Invalid credit card allocation')
       prepared_alloc.append((pid,card,amount,str(a.get('transaction_ref',''))[:100]));allocated=round(allocated+amount,2)
      if allocated>total+0.005:raise ValueError('Card allocations exceed invoice total')
      attachment=x.get('attachment','')
      if attachment and (not re.fullmatch('[a-f0-9]{32}\\.(pdf|jpg|jpeg|png|webp)',attachment) or not (UPLOADS/attachment).exists()):raise ValueError('Invalid attachment')
      c.execute('UPDATE purchases SET firm_id=?,vendor_id=?,invoice_no=?,invoice_date=?,notes=?,attachment=?,subtotal=?,discount=?,tax=?,total=?,status=? WHERE id=?',(firm,vendor,invoice_no,invoice_date,str(x.get('notes',''))[:1000],attachment,subtotal,discount,tax,total,'recorded' if abs(allocated-total)<.005 else 'partially_allocated',pid))
      c.execute('DELETE FROM purchase_lines WHERE purchase_id=?',(pid,));c.execute('DELETE FROM allocations WHERE purchase_id=?',(pid,))
      c.executemany('INSERT INTO purchase_lines(purchase_id,item_id,qty,rate,discount,tax_rate,tax_amount,line_total,description,identifiers) VALUES (?,?,?,?,?,?,?,?,?,?)',prepared)
      c.executemany('INSERT INTO allocations(purchase_id,card_id,amount,transaction_ref) VALUES (?,?,?,?)',prepared_alloc)
      audit(c,user['id'],'update','purchase',pid,invoice_no)
      return jsend(self,{'id':pid,'total':total,'allocated':allocated})
     if method=='DELETE':
      self.guard(user,admin=True);c.execute('UPDATE purchases SET deleted=1 WHERE id=?',(pid,));audit(c,user['id'],'cancel','purchase',pid);return jsend(self,{'ok':True})
   if path=='/api/upload' and method=='POST':
    x=self.input();mime=str(x.get('type',''));data=str(x.get('data',''))
    ext={'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'}.get(mime)
    if not ext:raise ValueError('Only PDF, JPG, PNG and WebP allowed')
    raw=base64.b64decode(data,validate=True)
    if len(raw)>7*1024*1024:raise ValueError('File exceeds 7 MB')
    if not ((ext=='pdf' and raw.startswith(b'%PDF')) or (ext=='jpg' and raw.startswith(b'\xff\xd8')) or (ext=='png' and raw.startswith(b'\x89PNG')) or (ext=='webp' and raw.startswith(b'RIFF') and raw[8:12]==b'WEBP')):raise ValueError('File signature not valid')
    name=secrets.token_hex(16)+'.'+ext;(UPLOADS/name).write_bytes(raw);return jsend(self,{'file':name})
   if path.startswith('/api/attachment/') and method=='GET':
    name=bits[-1]
    with db() as c:
     record=c.execute('SELECT firm_id FROM purchases WHERE attachment=? AND deleted=0',(name,)).fetchone()
    if not record or not allowed(user,record['firm_id']):raise PermissionError('No attachment access')
    if not re.fullmatch('[a-f0-9]{32}\\.(pdf|jpg|jpeg|png|webp)',name):raise ValueError('Invalid file')
    return jsend(self,(UPLOADS/name).read_bytes(),content_type=mimetypes.guess_type(name)[0] or 'application/octet-stream')
   if path=='/api/users' and method=='POST':
    self.guard(user,admin=True);x=self.input();name=str(x.get('username','')).strip();pw=str(x.get('password',''));role=str(x.get('role','user'))
    if not name or len(name)>255 or any(ord(ch)<32 for ch in name) or len(pw)<8 or len(pw)>1024 or role not in ('admin','user'):raise ValueError('Enter a username (up to 255 characters) and password (at least 8 characters)')
    access=str(x.get('allowed_firms','*'))
    if access!='*' and not re.fullmatch(r'\d+(,\d+)*',access):raise ValueError('Invalid firm access')
    with db() as c:
     try:
      cur=c.execute('INSERT INTO users(username,password,role,can_add_masters,allowed_firms,must_change) VALUES (?,?,?,?,?,1)',(name,passwd(pw),role,int(bool(x.get('can_add_masters',True))),access));audit(c,user['id'],'create','users',cur.lastrowid,name)
     except sqlite3.IntegrityError:raise ValueError('Username exists')
    return jsend(self,{'ok':True})
   if len(bits)==3 and bits[:2]==['api','users'] and bits[2].isdigit() and method=='PUT':
    self.guard(user,admin=True);uid=int(bits[2]);x=self.input()
    if uid==user['id'] and (x.get('active') is False or x.get('role')=='user'):raise ValueError('Cannot remove own admin access')
    setpart=[];args=[]
    for key in ('role','active','can_add_masters','allowed_firms'):
     if key in x:
      v=x[key]
      if key=='role' and v not in ('admin','user'):raise ValueError('Invalid role')
      if key in ('active','can_add_masters'):v=int(bool(v))
      if key=='allowed_firms' and v!='*' and not re.fullmatch(r'\d+(,\d+)*',str(v)):raise ValueError('Invalid firm list')
      setpart.append(key+'=?');args.append(v)
    if x.get('password'):
     if not 8<=len(str(x['password']))<=1024:raise ValueError('Password must be at least 8 characters')
     setpart+=['password=?','must_change=1'];args.append(passwd(str(x['password'])))
    if not setpart:raise ValueError('Nothing to update')
    with db() as c:c.execute('UPDATE users SET '+','.join(setpart)+' WHERE id=?',args+[uid]);audit(c,user['id'],'update','users',uid)
    return jsend(self,{'ok':True})
   if path=='/api/item-suggest' and method=='GET':
    # Public Wikidata suggestions (no API key); only the typed product words are sent.
    query=str(p.get('q','')).strip()
    if len(query)<3:return jsend(self,{'suggestions':[],'source':'Wikidata'})
    if len(query)>120:raise ValueError('Search phrase too long')
    url='https://www.wikidata.org/w/api.php?'+urllib.parse.urlencode({'action':'wbsearchentities','format':'json','language':'en','uselang':'en','type':'item','limit':8,'search':query})
    try:
     req=urllib.request.Request(url,headers={'User-Agent':'SmartPurchaseCardTracker/1.2 (product autocomplete; local app)','Accept':'application/json'})
     with urllib.request.urlopen(req,timeout=6) as response:
      result=json.load(response)
     suggestions=[]
     for entry in result.get('search',[]):
      label=str(entry.get('label','')).strip()
      if label:suggestions.append({'name':label[:220],'description':str(entry.get('description',''))[:240]})
     return jsend(self,{'suggestions':suggestions,'source':'Wikidata'})
    except Exception:
     return jsend(self,{'suggestions':[],'source':'Wikidata','notice':'Online suggestions unavailable. Enter the item manually.'})
   if path=='/api/reports':
    with db() as c:return jsend(self,report_rows(c,user,p.get('type','purchases'),p))
   if path=='/api/export':
    name=p.get('type','purchases');format=p.get('format','csv')
    with db() as c:rows=report_rows(c,user,name,p)
    if format=='csv':return jsend(self,csvbytes(rows),'200' if False else 200,'text/csv',name+'.csv')
    if format=='xlsx':return jsend(self,xlsxbytes(rows),200,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',name+'.xlsx')
    if format=='pdf':return jsend(self,pdfbytes(rows,name.title()+' Report'),200,'application/pdf',name+'.pdf')
    raise ValueError('Unsupported export format')
   if path=='/api/template':
    kind=p.get('type','')
    if kind not in SCHEMAS:raise ValueError('Unknown template')
    return jsend(self,xlsxbytes([{k:'' for k in fields_of(kind)}]),200,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',kind+'_sample.xlsx')
   if path=='/api/import' and method=='POST':
    self.guard(user,master=True);x=self.input();kind=x.get('type','');rows=x.get('rows',[]);commit=bool(x.get('commit'))
    if kind not in SCHEMAS or not isinstance(rows,list) or len(rows)>3000:raise ValueError('Invalid import data (max 3000 rows)')
    results=[];valid=[];seen=set()
    with db() as c:
     for ix,r in enumerate(rows,2):
      try:
       row=validate(kind,r);key=(row.get('gstin') or row['name'].lower()) if kind=='vendors' else (row['name'].lower() if kind in ('firms','items') else (row['holder'].lower(),row['issuer'].lower(),row['last4']))
       if key in seen:raise ValueError('Duplicate in uploaded file')
       seen.add(key)
       if kind=='cards':existing=c.execute('SELECT 1 FROM cards WHERE lower(holder)=? AND lower(issuer)=? AND last4=? AND deleted=0',key).fetchone()
       elif kind=='vendors' and row.get('gstin'):existing=c.execute('SELECT 1 FROM vendors WHERE gstin=? AND deleted=0',(row['gstin'],)).fetchone()
       else:existing=c.execute('SELECT 1 FROM '+kind+' WHERE lower(name)=? AND deleted=0',(row['name'].lower(),)).fetchone()
       if existing:raise ValueError('Already exists in database')
       valid.append((ix,row));results.append({'row':ix,'status':'valid','message':''})
      except Exception as e:results.append({'row':ix,'status':'skipped','message':str(e)})
     imported=0
     if commit:
      for ix,row in valid:
       try:
        with c:
         keys=list(row);cur=c.execute('INSERT INTO '+kind+' ('+','.join(keys)+') VALUES ('+','.join('?'*len(keys))+')',[row[k] for k in keys]);audit(c,user['id'],'import',kind,cur.lastrowid)
        imported+=1
       except Exception as e:
        for res in results:
         if res['row']==ix:res.update(status='skipped',message=str(e))
     return jsend(self,{'rows':results,'valid':len(valid),'imported':imported,'skipped':len(results)-len(valid)})
   return jsend(self,{'error':'Endpoint not found'},404)
  except PermissionError as e:return jsend(self,{'error':str(e)},403)
  except (ValueError,TypeError,KeyError,sqlite3.IntegrityError) as e:return jsend(self,{'error':str(e)},400)
  except Exception as e:
   print('Server error:',repr(e),file=sys.stderr);return jsend(self,{'error':'Unexpected server error'},500)

if __name__=='__main__':
 init()
 HOST=os.getenv('SMART_PURCHASE_HOST','127.0.0.1');PORT=int(os.getenv('SMART_PURCHASE_PORT','8765'))
 server=ThreadingHTTPServer((HOST,PORT),H)
 print(f'Smart Purchase application running at http://{HOST}:{PORT}',flush=True)
 if HOST=='127.0.0.1': threading.Timer(1.2,lambda:webbrowser.open(f'http://{HOST}:{PORT}')).start()
 try:server.serve_forever()
 except KeyboardInterrupt:pass
