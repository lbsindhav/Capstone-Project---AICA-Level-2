@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_APP.ps1"
if errorlevel 1 (
  echo.
  echo Application could not start. Review error above.
  pause
)
endlocal
